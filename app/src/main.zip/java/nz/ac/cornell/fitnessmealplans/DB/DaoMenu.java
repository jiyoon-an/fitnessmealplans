package nz.ac.cornell.fitnessmealplans.DB;

/**
 * Created by samsung on 27/05/2016.
 */
public class DaoMenu {
}
